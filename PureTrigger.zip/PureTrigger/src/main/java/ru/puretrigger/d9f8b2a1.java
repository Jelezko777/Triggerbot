package ru.puretrigger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;

public class d9f8b2a1 implements ClientModInitializer {
    // Выключен по умолчанию: включается клавишей R
    public static boolean active = false;

    private static boolean destroyed = false;
    private static boolean rWasDown = false;
    private static boolean insWasDown = false;
    private static int msgTicks = 0;

    @Override
    public void onInitializeClient() {
        c3e4x7v8.init();

        // Надпись ВКЛ / ВЫКЛ на экране (в чат и в логи ничего не пишется)
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("puretrigger", "hud"), (ctx, tickCounter) -> {
            if (destroyed || msgTicks <= 0) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;

            TextRenderer tr = mc.textRenderer;
            String msg = active ? "PureTrigger: ВКЛ" : "PureTrigger: ВЫКЛ";
            int color = active ? 0xFF55FF55 : 0xFFFF5555;
            int w = tr.getWidth(msg);
            ctx.drawTextWithShadow(tr, msg, (ctx.getScaledWindowWidth() - w) / 2,
                    ctx.getScaledWindowHeight() / 2 + 12, color);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (destroyed) return;
            long win = client.getWindow().getHandle();
            if (win == 0L) return;

            boolean rDown = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_R) == 1;
            boolean insDown = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_INSERT) == 1;

            if (client.currentScreen == null) {
                // R: включить / выключить
                if (rDown && !rWasDown) {
                    active = !active;
                    msgTicks = 60; // ~3 секунды
                }
                // Insert: полное отключение и удаление файла мода
                if (insDown && !insWasDown) {
                    selfDestruct();
                }
            }
            rWasDown = rDown;
            insWasDown = insDown;

            if (msgTicks > 0) msgTicks--;
        });
    }

    private static void selfDestruct() {
        destroyed = true;
        active = false;
        msgTicks = 0;
        try {
            FabricLoader.getInstance().getModContainer("puretrigger").ifPresent(c -> {
                for (Path p : c.getOrigin().getPaths()) {
                    if (!p.toString().endsWith(".jar") || !Files.isRegularFile(p)) continue;
                    try {
                        Files.deleteIfExists(p);
                    } catch (Throwable ignored) {
                    }
                    // если сразу не удалился (файл занят) — удалить при закрытии игры
                    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                        try {
                            Files.deleteIfExists(p);
                        } catch (Throwable ignored) {
                        }
                    }));
                }
            });
        } catch (Throwable ignored) {
        }
    }
}
