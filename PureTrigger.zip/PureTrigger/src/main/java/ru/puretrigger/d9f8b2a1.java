package ru.puretrigger;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class d9f8b2a1 implements ClientModInitializer {
    public static boolean active = true;
    private static boolean insertWasDown = false;
    private static int alertTicks = 0;

    @Override
    public void onInitializeClient() {
        c3e4x7v8.init();

        // Рендер статуса над прицелом вместо чата при нажатии Insert
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of("puretrigger", "hud"), (ctx, tickCounter) -> {
            if (!active && alertTicks > 0) {
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player != null && !mc.options.hudHidden) {
                    TextRenderer tr = mc.textRenderer;
                    String msg = "[System] Status updated.";
                    int sw = ctx.getScaledWindowWidth();
                    int sh = ctx.getScaledWindowHeight();
                    int w = tr.getWidth(msg);
                    ctx.drawTextWithShadow(tr, msg, (sw - w) / 2, sh / 2 + 12, 0xFFFF5555);
                }
            }
        });

        // Отслеживание нажатия Insert для моментального отключения
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            long win = client.getWindow().getHandle();
            if (win != 0L) {
                boolean insertDown = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_INSERT) == 1;
                if (insertDown && !insertWasDown && client.currentScreen == null) {
                    if (active) {
                        active = false;
                        alertTicks = 100; // Показывает надпись около 5 секунд
                    }
                }
                insertWasDown = insertDown;
            }
            if (alertTicks > 0) {
                alertTicks--;
            }
        });
    }
}