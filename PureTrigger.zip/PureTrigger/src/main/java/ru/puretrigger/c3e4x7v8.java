package ru.puretrigger;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class c3e4x7v8 {
    private static int sprintResetTicks = 0;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!d9f8b2a1.active) return;
            onTick(client);
        });
    }

    private static void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || !player.isAlive()) return;

        if (sprintResetTicks > 0) {
            sprintResetTicks--;
            player.setSprinting(false);
        }

        if (client.currentScreen != null) return;

        if (client.crosshairTarget instanceof EntityHitResult entityHit) {
            Entity target = entityHit.getEntity();
            
            if (target instanceof LivingEntity living && target.isAlive() && target != player) {
                if (player.distanceTo(living) > 3.5) return;

                // Кулдаун атаки 100% (майнкрафт кд)
                float cooldown = player.getAttackCooldownProgress(0.0F);
                if (cooldown < 1.0F) return;

                // Строго фаза падения для гарантированного крит-удара
                boolean isFalling = player.getVelocity().y < -0.08 
                    && !player.isOnGround() 
                    && !player.isClimbing() 
                    && !player.isTouchingWater()
                    && !player.hasVehicle();

                if (!isFalling) return;

                // Сброс спринта для максимального урона и отбрасывания
                if (player.isSprinting()) {
                    player.setSprinting(false);
                    sprintResetTicks = 3;
                }

                client.interactionManager.attackEntity(player, living);
                player.swingHand(Hand.MAIN_HAND);
            }
        }
    }
}